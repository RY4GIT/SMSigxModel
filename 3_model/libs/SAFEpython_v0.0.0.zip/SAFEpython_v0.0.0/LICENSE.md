'the Software': SAFEpython_v0.0.0 - Sensitivity Analysis For Everybody toolbox developed by Francesca Pianosi, Thorsten Wagener and Fanny Sarrazin and owned by the University of Bristol.

1) The University of Bristol grants, and you hereby accept, a non-exclusive, royalty-free license to use the Software for internal research and development use only and in accordance with the terms of this agreement.

2) You agree not to use the Software for any commercial purposes. Commercial purposes include charging a fee for any services that involve the use of the Software or incorporating any part of the Software within a commercial product. Should you need to use the Software for commercial purposes please contact: Francesca Pianosi

3) You agree not to re-distribute the Software and not to put the Software where it may be accessible to other individuals without your direct knowledge.

4) You acknowledge that the Software is the result of academic research and is supplied "AS IS", without obligation by the authors or the University of Bristol to provide accompanying services or support.  

5) You agree to load and use the Software entirely at your own risk and in no event will the University of Bristol be liable for any loss or damage of any kind. You hereby agree to defend, indemnify and hold harmless the University of Bristol against any liability or claim arising from your use of the Software.

6) The express terms of this agreement are in lieu of all warranties, conditions, undertakings, terms and obligations implied by statute, common law, trade usage, course of dealing or otherwise all of which are hereby excluded to the fullest extent permitted by law. The Software is provided, and accepted by you, WITHOUT ANY WARRANTY OF MERCHANTAITY OR FITNESS FOR PARTICULAR PURPOSE OR ANY OTHER WARRANTY, EXPRESSED OR IMPLIED.  Bristol in particular gives and makes no condition, other term, or provision or representation that any use of the Software will not infringe the rights of any person. No warranty is given that the information will be free from error or viruses.

7) You agree to acknowledge use of the Software in any reports or publications of results obtained with the Software

8) You agree, on request of the University of Bristol, to provide non-confidential information about how you are using the Software. You shall grant permission for the University of Bristol to use this material for reporting the impact of the original University of Bristol�s work

